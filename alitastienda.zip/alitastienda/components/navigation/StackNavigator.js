
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Details from '../Details'
import Home from '../Home'
import Menu from '../Menu'
import formulario2 from '../Formulariodos'



const Stack = createNativeStackNavigator();

export default function StackNavigator() {
  return (
    <NavigationContainer>
     <Stack.Navigator>
        <Stack.Screen name="Home" component={Home} />
         <Stack.Screen name="Details" component={Details} />
        <Stack.Screen name="Menu" component={Menu} />
       <Stack.Screen name="formulario2" component={formulario2} />
      </Stack.Navigator>
    
    

    </NavigationContainer>
  );
}


