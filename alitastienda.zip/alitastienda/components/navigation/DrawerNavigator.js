import View from 'react-native'
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import Details from '../Details'
import Home from '../Home'
import Menu from '../Menu'
import formulario2 from '../Formulariodos'
import AlitasForm from '../alitasform'



const Drawer = createDrawerNavigator();
const DrawerNavigator = () => {
  return(
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="Home" component={Home} />
        <Drawer.Screen name="Menu" component={Menu} />
        <Drawer.Screen name="Pedido" component={Details} />
        <Drawer.Screen name="Productos" component={AlitasForm} />

        <Drawer.Screen
  name="Pedido de carrito de compras"
  component={formulario2}
  options={{ drawerLabel: () => null }}
/>

        </Drawer.Navigator>
       
    </NavigationContainer>
  )
}

export default DrawerNavigator