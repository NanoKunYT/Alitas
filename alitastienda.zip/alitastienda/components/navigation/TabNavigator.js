import { NavigationContainer } from '@react-navigation/native'; 
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Details from '../Details'
import Home from '../Home'
import Menu from '../Menu'
import formulario2 from '../Formulariodos'
import { AntDesign } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  return (
     <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen 
        name="Home" 
        component={Home}
        options= {{
          title: 'Home',
          tabBarIcon: () =>(
            <AntDesign name="home" size={24} color="black" />
          )
        }} />
        <Tab.Screen 
        name="Menu" 
        component={Menu} />
        <Tab.Screen name="Details" component={Details} />
        <Tab.Screen 
        name="formulario2" 
        component={formulario2}
        options= {{
          title: 'Formulario 2',
          tabBarIcon: () =>(
            <AntDesign name="formulario 2" size={24} color="black" />
          )
        }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}