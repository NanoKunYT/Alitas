import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, Alert, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';
import firebase from '../database/firebase'; 

export default function AlitasForm() {
  const [alitas, setAlitas] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [piezas, setPiezas] = useState('');
  const [precio, setPrecio] = useState('');
  const [alitasList, setAlitasList] = useState([]);
  const [selectedItemId, setSelectedItemId] = useState(null);

  useEffect(() => {
    const alitasRef = firebase.database().ref('alitas');
    alitasRef.on('value', (snapshot) => {
      const alitasData = snapshot.val();
      if (alitasData) {
        const keys = Object.keys(alitasData);
        const alitasArray = keys.map((key) => ({ id: key, ...alitasData[key] }));
        setAlitasList(alitasArray);
      } else {
        setAlitasList([]);
      }
    });
  }, []);

  const handleAdd = () => {
    const alitasRef = firebase.database().ref('alitas');
    const alitasData = {
      alitas: alitas,
      descripcion: descripcion,
      piezas: piezas,
      precio: precio
    };
    alitasRef.push(alitasData);
    Alert.alert('Success', 'Alitas añadidas con éxito!');
    setAlitas('');
    setDescripcion('');
    setPiezas('');
    setPrecio('');
  };

  const handleEdit = () => {
    const alitasRef = firebase.database().ref('alitas').child(selectedItemId);
    const alitasData = {
      alitas: alitas,
      descripcion: descripcion,
      piezas: piezas,
      precio: precio
    };

    alitasRef.update(alitasData)
      .then(() => {
        Alert.alert('Edit', 'Alitas editadas con éxito!');
        setAlitas('');
        setDescripcion('');
        setPiezas('');
        setPrecio('');
        setSelectedItemId(null); 
      })
      .catch((error) => {
        console.error("Error updating document: ", error);
        Alert.alert('Error', 'Error al editar alitas.');
      });
  };

  const handleSelectEdit = (id, alitasData) => {
    setSelectedItemId(id); 
    setAlitas(alitasData.alitas);
    setDescripcion(alitasData.descripcion);
    setPiezas(alitasData.piezas);
    setPrecio(alitasData.precio);
  };

  const handleDelete = (id) => {
    const alitasRef = firebase.database().ref('alitas').child(id);
    alitasRef.remove();
    Alert.alert('Delete', 'Alitas eliminadas!');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image
          source={require('../assets/logoalitas.png')}
          style={styles.logo}
          resizeMode="contain"
        />
        <Text style={styles.title}>Alitas GaboNaso</Text>
      </View>
      <TextInput
        style={styles.input}
        placeholder="Alitas"
        value={alitas}
        onChangeText={setAlitas}
        placeholderTextColor="#fff"
      />
      <TextInput
        style={styles.input}
        placeholder="Descripción"
        value={descripcion}
        onChangeText={setDescripcion}
        placeholderTextColor="#fff"
      />
      <TextInput
        style={styles.input}
        placeholder="Piezas"
        value={piezas}
        onChangeText={setPiezas}
        keyboardType="numeric"
        placeholderTextColor="#fff"
      />
      <TextInput
        style={styles.input}
        placeholder="Precio"
        value={precio}
        onChangeText={setPrecio}
        keyboardType="numeric"
        placeholderTextColor="#fff"
      />
      <Button 
        title={selectedItemId ? "Editar Alitas" : "Agregar Alitas"} 
        onPress={selectedItemId ? handleEdit : handleAdd} 
        color="#8b0000"
      />

      <Text style={styles.listTitle}>Lista de Alitas</Text>
      <FlatList
        data={alitasList}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.itemContainer}
            onPress={() => handleSelectEdit(item.id, item)}
          >
            <Text style={styles.itemText}>{item.alitas}</Text>
            <Text style={styles.itemText}>{item.descripcion}</Text>
            <Text style={styles.itemText}>{item.piezas}</Text>
            <Text style={styles.itemText}>${item.precio}</Text>
            <View style={styles.buttonContainer}>
              <Button
                title="Editar"
                onPress={() => handleSelectEdit(item.id, item)}
                color="#8b0000"
              />
              <Button
                title="Eliminar"
                onPress={() => handleDelete(item.id)}
                color="#8b0000"
              />
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 20,
    color: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  logo: {
    width: 80,
    height: 80,
    marginRight: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  input: {
    height: 40,
    borderColor: '#fff',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    color: '#fff',
  },
  listTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
    color: '#fff',
  },
  itemContainer: {
    backgroundColor: '#333',
    padding: 16,
    marginVertical: 8,
    borderRadius: 8,
  },
  itemText: {
    fontSize: 16,
    marginBottom: 5,
    color: '#fff',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
});
