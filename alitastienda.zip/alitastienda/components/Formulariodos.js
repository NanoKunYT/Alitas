import React, { useState } from 'react';
import { View, StyleSheet, Text, TextInput, Button, Linking } from 'react-native';

const Formulario2 = ({ route }) => {
  const { cart } = route.params; // Obtener el carrito de productos seleccionados desde la navegación

  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');

  const handleMessage = () => {
    // Construir el mensaje con la información del cliente y los productos seleccionados
    let message = `Hola, soy ${name}. Mi dirección es ${address}. Mi número de teléfono es ${phone}. Me gustaría hacer un pedido con los siguientes productos:\n\n`;

    // Agregar cada producto al mensaje
    cart.forEach(item => {
      message += `${item.name} - ${item.price}\n`;
    });

    // Codificar el mensaje para usar en la URL de WhatsApp
    const encodedMessage = encodeURIComponent(message);

    // Número de teléfono de la tienda
    const phoneNumber = '+52 1 221 199 0702';

    // URL de WhatsApp con el mensaje y el número de teléfono
    const whatsappURL = `whatsapp://send?phone=${phoneNumber}&text=${encodedMessage}`;

    // Verificar si se puede abrir la URL de WhatsApp y abrir la aplicación
    Linking.canOpenURL(whatsappURL)
      .then((supported) => {
        if (!supported) {
          console.log("No se puede abrir WhatsApp.");
        } else {
          return Linking.openURL(whatsappURL);
        }
      })
      .catch((error) => console.log("Error al verificar compatibilidad de URL:", error));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Realizar Pedido Personalizado</Text>
      
      {/* Mostrar los productos seleccionados */}
      <View style={styles.cartContainer}>
        <Text style={styles.subtitle}>Productos Seleccionados:</Text>
        {cart.map(item => (
          <View key={item.id} style={styles.productItem}>
            <Text>{item.name} - {item.price}</Text>
          </View>
        ))}
      </View>

      {/* Formulario de datos del cliente */}
      <TextInput
        style={styles.input}
        placeholder="Nombre"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Dirección"
        value={address}
        onChangeText={setAddress}
      />
      <TextInput
        style={styles.input}
        placeholder="Teléfono"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
      />

      {/* Botón para enviar el mensaje a WhatsApp */}
      <Button
        title="Enviar Mensaje a WhatsApp"
        onPress={handleMessage}
        color="#330000" // Color de botón personalizado
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#CC3333', // Fondo negro
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#fff', // Texto blanco
  },
  subtitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#fff', // Texto blanco
  },
  cartContainer: {
    marginBottom: 20,
  },
  productItem: {
    marginBottom: 5,
    color: '#fff', // Texto blanco
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 20,
    paddingHorizontal: 10,
    backgroundColor: '#fff', // Fondo blanco para el input
  },
});

export default Formulario2;
