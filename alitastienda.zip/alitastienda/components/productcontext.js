import React, { createContext, useState, useEffect } from 'react';
import firebase from '../database/firebase';

// Creamos un contexto
export const ProductContext = createContext();

// Proveedor del contexto
export const ProductProvider = ({ children }) => {
  const [alitasList, setAlitasList] = useState([]);

  // Función para cargar los productos desde Firebase
  useEffect(() => {
    const alitasRef = firebase.database().ref('alitas');
    alitasRef.on('value', (snapshot) => {
      const alitasData = snapshot.val();
      if (alitasData) {
        const keys = Object.keys(alitasData);
        const alitasArray = keys.map((key) => ({ id: key, ...alitasData[key] }));
        setAlitasList(alitasArray);
      } else {
        setAlitasList([]);
      }
    });
  }, []);

  return (
    <ProductContext.Provider value={{ alitasList, setAlitasList }}>
      {children}
    </ProductContext.Provider>
  );
};
