import React, { useState } from 'react';
import { View, StyleSheet, Text, TextInput, Button, Linking, Image } from 'react-native';

//Este es el formulario 1
const Details = () => {
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');

  const handleMessage = () => {
    const message = `Hola, soy ${name}. Mi dirección es ${address}. Mi número de teléfono es ${phone}. Me gustaría hacer un pedido.`;
    const phoneNumber = '+52 1 221 199 0702'; // Reemplaza esto con el número de teléfono de la tienda
    const whatsappURL = `whatsapp://send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`;
    
    Linking.canOpenURL(whatsappURL)
      .then((supported) => {
        if (!supported) {
          console.log("No se puede abrir WhatsApp.");
        } else {
          return Linking.openURL(whatsappURL);
        }
      })
      .catch((error) => console.log("Error al verificar compatibilidad de URL:", error));
  };

  return (
    <View style={styles.container}>
    <Image
          source={require('../assets/logoalitas.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      <Text style={styles.title}>Realizar Pedido</Text>
      <TextInput
        style={styles.input}
        placeholder="Nombre"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Dirección"
        value={address}
        onChangeText={setAddress}
      />
      <TextInput
        style={styles.input}
        placeholder="Teléfono"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
      />
      <Button
        title="Enviar Mensaje a WhatsApp"
        onPress={handleMessage}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000000', // Fondo negro
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#fff', // Texto blanco
  },
  
  logo: {
    width: '80%',
    height: 200,
    marginBottom: 20,
    borderRadius: 10,
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 20,
    paddingHorizontal: 10,
    backgroundColor: '#fff', // Fondo blanco para el input
  },
  
});


export default Details;
