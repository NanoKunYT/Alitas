import React, { useState } from 'react';
import { View, StyleSheet, Text, Button, ScrollView, Image, TouchableOpacity } from 'react-native';

const Menu = ({ navigation }) => {
  const [cart, setCart] = useState([]);

  // Lista de productos
  const products = [
    {
      id: 1,
      name: 'Alitas Picantes',
      description: 'Alitas de pollo bañadas en salsa picante.',
      price: '$10',
      image: require('../assets/rebel-wings-buffet-de-alitas.webp')
    },
    {
      id: 2,
      name: 'Alitas BBQ',
      description: 'Alitas de pollo con salsa BBQ.',
      price: '$12',
      image: require('../assets/alita1.webp')
    },
    {
      id: 3,
      name: 'Alitas insanas',
      description: 'Alitas de pollo.',
      price: '$79',
      image: require('../assets/imagen1.webp')
    },
    {
      id: 4,
      name: 'Paquete alitas',
      description: 'Alitas de pollo con refresco y papas.',
      price: '$49',
      image: require('../assets/imagen2.webp')
    },
    {
      id: 5,
      name: 'Alitas PAQ',
      description: 'Alitas de pollo con papas (100 gramos))',
      price: '$50',
      image: require('../assets/imagen3.webp')
    },
    {
      id: 6,
      name: 'Alitas UwU',
      description: 'Alitas de pollo con papas y salsa.',
      price: '$100',
      image: require('../assets/imagen4.webp')
    },
    {
      id: 7,
      name: 'Alitas fit',
      description: 'Alitas de pollo con verduras.',
      price: '$70',
      image: require('../assets/imagen5.webp')
    },
    {
      id: 8,
      name: 'Alitas etesech',
      description: 'Alitas de pollo insanas',
      price: '$80',
      image: require('../assets/imagen6.webp')
    },
    {
      id: 9,
      name: 'Alitas bellakas',
      description: 'Alitas de pollo .',
      price: '$50',
      image: require('../assets/imagen7.jpg')
    },
    {
      id: 10,
      name: 'Alitas PAQUETE Familiar',
      description: 'Paquete familiar de Alitas de pollo .',
      price: '$100',
      image: require('../assets/imagen8.webp')
    },
  ];

  // Función para agregar un producto al carrito
  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  // Función para eliminar un producto del carrito
  const removeFromCart = (productId) => {
    const updatedCart = cart.filter(item => item.id !== productId);
    setCart(updatedCart);
  };

  // Función para calcular el total del carrito
  const calculateTotal = () => {
    return cart.reduce((total, item) => total + parseFloat(item.price.replace('$', '')), 0).toFixed(2);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
    <Image
          source={require('../assets/logoalitas.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      <Text style={styles.title}>Nuestro Menú</Text>
      {products.map(product => (
        <TouchableOpacity
          key={product.id}
          style={styles.productContainer}
          onPress={() => navigation.navigate('Detalles del Producto', { product })}
        >
          <Image source={product.image} style={styles.productImage} />
          <View style={styles.productInfo}>
            <Text style={styles.productName}>{product.name}</Text>
            <Text style={styles.productDescription}>{product.description}</Text>
            <Text style={styles.productPrice}>{product.price}</Text>
          </View>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => addToCart(product)}
          >
            <Text style={styles.addButtonText}>Agregar al Carrito</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      ))}
      {/* Carrito de Compras */}
      <View style={styles.cartContainer}>
        <Text style={styles.cartTitle}>Carrito de Compras</Text>
        {cart.map(item => (
          <View key={item.id} style={styles.cartItem}>
            <Text style={styles.cartItemText}>{item.name} - {item.price}</Text>
            <TouchableOpacity style={styles.removeButton} onPress={() => removeFromCart(item.id)}>
              <Text style={styles.removeButtonText}>Eliminar</Text>
            </TouchableOpacity>
          </View>
        ))}
        <Text style={styles.cartTotal}>Total: ${calculateTotal()}</Text>
        <Button
          title="Hacer pedido Personalizado"
          onPress={() => navigation.navigate('Pedido', { cart })}
          color='#8b0000'
        />
        <Button
          title="Realizar Pedido del carrito de compras"
          onPress={() => navigation.navigate('Pedido de carrito de compras', { cart })}
          color='#660066'
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#000', // Fondo negro
    paddingVertical: 20,
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#fff', // Texto blanco
  },
  productContainer: {
    marginTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#ccc',
    paddingTop: 10,
    flexDirection: 'colum',
   
  },
  logo: {
     width: '100%',
    height: 200,
    marginBottom: 20,
    borderRadius: 10,
  },
  productImage: {
    width: 100,
    height: 100,
    borderRadius: 5,
    marginRight: 10,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#fff', // Texto blanco
  },
  productDescription: {
    fontSize: 16,
    marginBottom: 5,
    color: '#fff', // Texto blanco
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff', // Texto blanco
  },
  addButton: {
    backgroundColor: '#8b0000', // Botón de agregar al carrito rojo oscuro
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
  },
  addButtonText: {
    color: '#fff', // Texto blanco
    fontWeight: 'bold',
  },
  cartContainer: {
    marginTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#8b0000', // Borde superior rojo oscuro
    paddingTop: 10,
  },
  cartTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#fff', // Texto rojo oscuro
  },
  cartItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  cartItemText: {
    fontSize: 16,
    flex: 1,
    color: '#fff', // Texto blanco
  },
  removeButton: {
    backgroundColor: '#8b0000', // Botón de eliminar rojo oscuro
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
  },
  removeButtonText: {
    color: '#fff', // Texto blanco
    fontWeight: 'bold',
  },
  cartTotal: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'right',
    marginTop: 10,
    color: '#fff', // Texto rojo oscuro
  },
});

export default Menu;