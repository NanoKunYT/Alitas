import React from 'react';
import { View, StyleSheet, Text, ScrollView, Image, Button } from 'react-native';

const Home = ({ navigation }) => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.backgroundContainer}>
        <Image
          source={require('../assets/logoalitas.png')}
          style={styles.logo}
          resizeMode="contain"
        />
       
        <View style={styles.content}>
       
          <Text style={styles.title}>Bienvenido a Alitas Ricas</Text>
        
          <Image
            source={require('../assets/alita1.webp')}
            style={styles.image}
            resizeMode="cover"
          />
          
          <Text style={styles.subtitle}>Disfruta de nuestras ofertas:</Text>
          <View style={styles.offerContainer}>
            <Text style={styles.offerText}>¡Oferta especial los dias sabados!</Text>
            <Text style={styles.offerDetails}>50% de descuento en alitas picantes</Text>
          </View>
          <Text style={styles.contactTitle}>Puedes contactarnos:</Text>
          <View style={styles.contactContainer}>
            <Text style={styles.contactInfo}>Dirección: Av. Principal #123</Text>
            <Text style={styles.contactInfo}>Teléfono: 555-123-4567</Text>
            <Text style={styles.contactInfo}>Correo Electrónico: info@alitasricas.com</Text>
          </View>
          {/* Botón de navegación */}
          <Button
            title="Ir al Menú"
            onPress={() => navigation.navigate('Menu')}
            color='#8b0000'
          />
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#000',
    alignItems: 'center', // Centra el contenido horizontalmente
  },
  backgroundContainer: {
    flex: 1,
    width: '100%',
    backgroundColor: 'transparent', // Fondo transparente para aplicar degradado
    justifyContent: 'flex-end', // Alinea el contenido al final del contenedor
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 1,
    alignSelf: 'center', 
  },
  content: {
    paddingHorizontal: 16,
    paddingBottom: 20, // Espaciado inferior para el contenido
  },
  title: {
     fontFamily: 'Archivo-Bold',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: 'red',
  },
  image: {
    width: '100%',
    height: 200,
    marginBottom: 20,
    borderRadius: 10,
  },
  subtitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#ff5733', // Color de texto naranja
  },
  offerContainer: {
    backgroundColor: '#8b0000', // Color de fondo rojo oscuro
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
  },
  offerText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#fff', // Color de texto blanco
  },
  offerDetails: {
    fontSize: 14,
    color: '#fff', // Color de texto blanco
  },
  contactTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#ff5733', // Color de texto naranja
  },
  contactContainer: {
    marginBottom: 20,
  },
  contactInfo: {
    fontSize: 16,
    marginBottom: 5,
    color: '#fff', // Color de texto blanco
  },
});

export default Home;
