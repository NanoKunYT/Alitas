import StackNavigator from './components/navigation/StackNavigator'
import TabNavigator from './components/navigation/TabNavigator'
import DrawerNavigator from './components/navigation/DrawerNavigator'

export default function App() {
  return (
    
    <DrawerNavigator/>
    
    
  );
}

